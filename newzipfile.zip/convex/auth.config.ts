export default {
  providers: [
    {
      domain: "https://peaceful-baboon-38.clerk.accounts.dev/",
      applicationID: "convex",
    },
  ],
};
